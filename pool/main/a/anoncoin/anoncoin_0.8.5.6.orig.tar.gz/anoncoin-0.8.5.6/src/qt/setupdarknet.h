#ifndef SETUPDARKNET_H
#define SETUPDARKNET_H

void runFirstRunWizard();
void FinishWizard(int darknet);

#endif
